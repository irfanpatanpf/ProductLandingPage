# Product-Landing-Page
Product landing page you will use columns and align the components of the landing page within columns. Basic editing tasks like cropping images and making use of design templates are also covered in this.  Skills Required – CSS, Image editing.
